export class PkSpace{
	id:number;
	S_date:Date;
	E_date:Date;
	Fee:number;
}