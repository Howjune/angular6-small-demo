import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-data-sort',
  templateUrl: './data-sort.component.html',
  styleUrls: ['./data-sort.component.css']
})
export class DataSortComponent implements OnInit  {


  ngOnInit(){
    
  }
}

