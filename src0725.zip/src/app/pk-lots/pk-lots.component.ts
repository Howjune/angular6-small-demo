import { Component, OnInit } from '@angular/core';
import { PkSpace } from '../pkSpace';
import { ParkingService} from '../parking-service.service';

@Component({
  selector: 'app-pk-lots',
  templateUrl: './pk-lots.component.html',
  styleUrls: ['./pk-lots.component.css']
})
export class PkLotsComponent implements OnInit {

  pkLots:PkSpace[];
  getpkLots():void{
    this.parkingService.getpkLots()
    .subscribe(pkLots => this.pkLots=pkLots);
  }
   add(id:number,S_time:Date,E_time:Date,Fee:number):void{
	
   	this.parkingService.addPkLots({id:id,S_time:S_time,E_time:E_time,Fee:Fee} as PkSpace)
   	.subscribe(PkSpace =>{this.pkLots.push(PkSpace);});
   	
  }
  delete(pkSpace:PkSpace):void{
  	this.pkLots=this.pkLots.filter(t => t !== pkSpace);
  	this.parkingService.deletepkSpace(pkSpace)
  	.subscribe(()=> console.log('删除成功!'))
  }
  constructor(private parkingService:ParkingService) { }

  ngOnInit() {
  	this.getpkLots();
  }

}
