export interface PkSpace{
	id:number;
	S_time:Date;
	E_time:Date;
	Fee:number;
}