import { InMemoryDbService } from 'angular-in-memory-web-api';


export class InMemoryDataService implements InMemoryDbService{


	createDb(){

		const pkLots=[
		{
			id:1,
			S_date:new Date(2018,7-1,20).toLocaleDateString(),
			S_time:new Date('T10:10:10').toLocaleTimeString(),
			E_date:new Date('2018-07-20').toLocaleDateString(),
			E_time:new Date('T12:10:10').toLocaleTimeString(),
			Fee:10,
		},

		{
			id:2,
			S_date:new Date(2018,7-1,20).toLocaleDateString(),
			S_time:new Date('T10:10:10').toLocaleTimeString(),
			E_date:new Date('2018-07-20').toLocaleDateString(),
			E_time:new Date('T12:10:10').toLocaleTimeString(),
			Fee:10,
		},
		
		{
			id:3,
			S_date:new Date(2018,7-1,20).toLocaleDateString(),
			S_time:new Date('T10:10:10').toLocaleTimeString(),
			E_date:new Date('2018-07-20').toLocaleDateString(),
			E_time:new Date('T12:10:10').toLocaleTimeString(),
			Fee:10,
		},
		
		{
			id:4,
			S_date:new Date(2018,7-1,20).toLocaleDateString(),
			S_time:new Date('T10:10:10').toLocaleTimeString(),
			E_date:new Date('2018-07-20').toLocaleDateString(),
			E_time:new Date('T12:10:10').toLocaleTimeString(),
			Fee:10,
		},
		
		{
			id:5,
			S_date:new Date(2018,7-1,20).toLocaleDateString(),
			S_time:new Date('T10:10:10').toLocaleTimeString(),
			E_date:new Date('2018-07-20').toLocaleDateString(),
			E_time:new Date('T12:10:10').toLocaleTimeString(),
			Fee:10,
		}
		];
		return {pkLots}; 
	}
}