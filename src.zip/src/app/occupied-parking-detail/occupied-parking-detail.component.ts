import { Component, OnInit ,Input} from '@angular/core';

import { PkSpace } from '../pkSpace';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ParkingService } from '../parking-service.service';

@Component({
  selector: 'app-occupied-parking-detail',
  templateUrl: './occupied-parking-detail.component.html',
  styleUrls: ['./occupied-parking-detail.component.css']
})
export class OccupiedParkingDetailComponent implements OnInit {

  @Input() pkSpace:PkSpace;
  constructor(private route:ActivatedRoute,private parkingService:ParkingService,private location:Location) { }

  ngOnInit() {
  	this.getpkSpace();
  }
  save():void{
  	this.parkingService.updatepkSpace(this.pkSpace)
  	.subscribe(() => this.goBack());
  };
  getpkSpace():void{
  	const id= +this.route.snapshot.paramMap.get('id');
  	this.parkingService.getpkSpace(id)
  		.subscribe(pkSpace => this.pkSpace = pkSpace);
  }
  goBack():void{
  	this.location.back();
  }
}
