export interface PkSpace{
	id:number;
	S_time:string;
	E_time:string;
	Fee:number;
}