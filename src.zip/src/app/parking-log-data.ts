import { InMemoryDbService } from 'angular-in-memory-web-api';


export class InMemoryDataService implements InMemoryDbService{


	createDb(){

		const pkLots=[
		{
			id:1,
			S_time:'7-17 08:00:00',
			E_time:'7-17 10:00:00',
			Fee:10,
		},

		{
			id:2,
			S_time:'7-17 08:00:00',
			E_time:'7-17 10:00:00',
			Fee:10,
		},
		
		{
			id:3,
			S_time:'7-17 08:00:00',
			E_time:'7-18 10:00:00',
			Fee:50,
		},
		
		{
			id:4,
			S_time:'7-18 10:00:00',
			E_time:'',
			Fee:0,
		},
		
		{
			id:5,
			S_time:'7-18 12:00:00',
			E_time:'',
			Fee:0,
		}
		];
		return {pkLots}; 
	}
}