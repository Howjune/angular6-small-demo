import { Component, OnInit } from '@angular/core';
import { PkSpace } from '../pkSpace';
import { ParkingService} from '../parking-service.service';

@Component({
  selector: 'app-empty-parking',
  templateUrl: './empty-parking.component.html',
  styleUrls: ['./empty-parking.component.css']
})
export class EmptyParkingComponent implements OnInit {
  pkLots:PkSpace[];
  getpkLots():void{
    this.parkingService.getpkLots()
    .subscribe(pkLots => this.pkLots=pkLots);
  };
  add(id:number,S_time:string,E_time:string,Fee:number):void{

     this.parkingService.addPkLots({id,S_time,E_time,Fee} as PkSpace)
    .subscribe(PkSpace => {this.pkLots.push(PkSpace)})
  };
  delete(pkSpace:PkSpace):void{
    this.pkLots=this.pkLots.filter(t => t !== pkSpace);
    this.parkingService.deletepkSpace(pkSpace)
    .subscribe(()=> console.log('删除成功!'))
  }
  constructor(private parkingService:ParkingService) { }

  ngOnInit() {
  	this.getpkLots();
  }

}
